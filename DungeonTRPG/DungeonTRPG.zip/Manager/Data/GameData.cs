﻿using Newtonsoft.Json;
namespace DungeonTRPG.Manager.Data
{
    internal class GameData
    {
        public ActiveItemDB ActiveItemDB { get; private set; }
        public EquipItemDB EquipItemDB { get; private set; }
        public SkillDB SkillDB { get; private set; }
        public EnemyDB EnemyDB { get; private set; }
        public SecretItemDB SecretItemDB { get; internal set; }

        public GameData()
        {
            ActiveItemDB = new ActiveItemDB();
            EquipItemDB = new EquipItemDB();
            SkillDB = new SkillDB();
            EnemyDB = new EnemyDB();
            SecretItemDB = new SecretItemDB();
        }
    }
}
