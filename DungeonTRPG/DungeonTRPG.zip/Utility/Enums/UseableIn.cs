﻿namespace DungeonTRPG.Utility.Enums
{
    public enum UseableIn
    {
        OnlyCombat,
        OnlyIdle,
        Both
    }
}
