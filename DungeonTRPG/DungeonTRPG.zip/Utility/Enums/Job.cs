﻿namespace DungeonTRPG.Utility.Enums
{
    public enum Job
    {
        None,
        Warrior,
        Mage,
        Archer
    }
}
