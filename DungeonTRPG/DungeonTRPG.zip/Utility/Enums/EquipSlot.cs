﻿namespace DungeonTRPG.Utility.Enums
{
    public enum EquipSlot
    {
        HELMET,
        CHESTPLATE,
        LEGGINGS,
        BOOTS,
        WEAPON,
        ACCESSORY
    }
}